/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algooritmo_bellman.ford;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author user
 */
public class Prueba {
    public static void main (String [] args ){
        List<Vertice> verticeList = new ArrayList();
        
        verticeList.add(new Vertice("a"));
        verticeList.add(new Vertice("b"));
        verticeList.add(new Vertice("c"));
        verticeList.add(new Vertice("d"));
        verticeList.add(new Vertice("e"));
        verticeList.add(new Vertice("f"));
       

        
        List<Borde> bordeList;
        bordeList = new ArrayList();
        
        bordeList.add(new Borde(4, verticeList.get(0),verticeList.get(1)));
        bordeList.add(new Borde(2, verticeList.get(0),verticeList.get(2)));
        bordeList.add(new Borde(6, verticeList.get(1),verticeList.get(3)));
        bordeList.add(new Borde(3, verticeList.get(1),verticeList.get(2)));
        bordeList.add(new Borde(10, verticeList.get(1),verticeList.get(4)));
        bordeList.add(new Borde(-3, verticeList.get(2),verticeList.get(3)));
        bordeList.add(new Borde(8, verticeList.get(2),verticeList.get(4)));
        bordeList.add(new Borde(5, verticeList.get(3),verticeList.get(4)));
        
        
        
        BF algoritmo = new BF ( bordeList,verticeList);
        
        algoritmo.Distanciaminima(verticeList.get(0) ,verticeList.get(4));
        
        
        
     
        
        
                
        
    }
    
}
