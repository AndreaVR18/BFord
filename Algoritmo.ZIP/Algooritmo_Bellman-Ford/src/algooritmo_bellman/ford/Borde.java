/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algooritmo_bellman.ford;

/**
 *
 * @author user
 */
public class Borde { 
    
    
    private double peso;
    private Vertice inicio ;
    private Vertice destino;

    public Borde(double peso, Vertice inicio, Vertice destino) {
        this.peso = peso;
        this.inicio = inicio;
        this.destino = destino;
    }
    

    public double getPeso() {
        return peso;
    }

    public void setPeso(double peso) {
        this.peso = peso;
    }

    public Vertice getInicio() {
        return inicio;
    }

    public void setInicio(Vertice inicio) {
        this.inicio = inicio;
    }

    public Vertice getDestino() {
        return destino;
    }

    public void setDestino(Vertice destino) {
        this.destino = destino;
    }
    
    
    
    
}
