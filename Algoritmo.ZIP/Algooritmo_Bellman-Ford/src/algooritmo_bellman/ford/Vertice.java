/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package algooritmo_bellman.ford;

import java.util.List;

/**
 *
 * @author user
 */
public class Vertice {
    
    private String nombre;
    private boolean visita;
    // aplicamos el max value porque en un inicio del
    //vertice origen al de destino no se conce su trayectoria (infinito)
    private double Distanciaminima= Double.MAX_VALUE;
    private List<Borde> adjacenciesList;
    private  Vertice previo;

    public Vertice(String nombre) {
        this.nombre = nombre;
        this.adjacenciesList = adjacenciesList;
    }

    
    public void insertarborde(Borde borde){
        this.adjacenciesList.add(borde);
        
    }

    public boolean isVisita() {
        return visita;
    }

    public void setVisita(boolean visita) {
        this.visita = visita;
    }

    public double getDistanciaminima() {
        return Distanciaminima;
    }

    public void setDistanciaminima(double Distanciaminima) {
        this.Distanciaminima = Distanciaminima;
    }

    public Vertice getPrevio() {
        return previo;
    }

    public void setPrevio(Vertice previo) {
        this.previo = previo;
    }

    public List<Borde> getAdjacenciesList() {
        return adjacenciesList;
    }
    

    
    
    
    
    
    
    
    
    
    
    
}
