/*

 */
package algooritmo_bellman.ford;

import java.util.List;

/**
 *
 * @author user
 */
public class BF {
    
        private List<Borde> bordeList;
        private List<Vertice> verticeList;

        public BF(List<Borde> bordeList, List<Vertice> verticeList) {
            this.bordeList = bordeList;
            this.verticeList = verticeList;
        }

        public void Distanciaminima( Vertice origen, Vertice destino){
            //inica con origen peso  cero
            origen.setDistanciaminima(0);
            
            
            // se le disminye 1 porque el numero de iteraciones tiene que ser N ( numero de vertices - 1 si  exite mas de N-1 el algortimo no sirve
            for (int i = 0; i < this.verticeList.size()-1; i++) 
            {
                for(Borde borde :this.bordeList)
                {
                   
                    if(borde.getInicio().getDistanciaminima() ==Double.MAX_VALUE) continue ;
                        Vertice d = borde.getDestino();
                        Vertice o=borde.getInicio();
                    double nuevaDistancia = o.getDistanciaminima()+ borde.getPeso();
                    
                    if( nuevaDistancia < d.getDistanciaminima()){
                        d.setDistanciaminima(nuevaDistancia);
                        d.setPrevio(o);
                        
                    }  
                }
            }
             for(Borde borde :this.bordeList)
                {
                    if(borde.getInicio().getDistanciaminima() != Double.MAX_VALUE) continue ;
                        if ( ciclo(borde)){
                            System.out.println("El ciclo es negativo");
                            return ;
                        }
                }
                if (destino.getDistanciaminima() ==Double.MAX_VALUE){
                    System.out.println("No  existe un camino corto");
                }else
                {
                    System.out.println("El camino corto es :"+destino.getDistanciaminima());
                }
            
        }
        
        private boolean  ciclo(Borde borde){
            return borde.getInicio().getDistanciaminima() + borde.getPeso() < borde.getDestino().getDistanciaminima();}
            
        
   

 
    
}
