
import java.util.Arrays;


public class BF
{ 
    

//generamos un funcion recursiva para hallar el peso 

public static int devuelvePeso(int matriz[][],int nodoprevio,int nododestino, int numA)
{
    for(int i=0;i<numA;i++){ 
        if(matriz[i][0]==nodoprevio && matriz[i][1]==nododestino)
            return matriz[i][2] ;
    }
    return -1;
}

//una funcion recursiva para hallar  el camino mas corto 
public static int camino_corto(int previo[], int matriz[][] ,int nododestino , int suma, int numA)
{
    // en el caso  previo ya no tenga el valor establecido como -1
    if(previo[nododestino]!=-1)
        suma = camino_corto(previo,matriz, previo[nododestino],suma + devuelvePeso(matriz,previo[nododestino],nododestino,numA), numA);
    System.out.print("->"  +nododestino + " ");        
    return suma;
}
 


static void BellmanFord(int matriz[][], int numV, int numA, 
                int nodoorigen, int nododestino) 
{ 
    // se generan dos arrays para almacenar la distancia y los valores previos
    int []distancia = new int[numV]; 
    int []previo = new int[numV];
    // se recorre la distancia y se coloca un valor grance ya que tienda al infinito
    //se reccore el arreglo previo y se coloca como valor de inicializacion -1 
    for (int i = 0; i < numV; i++) {
        distancia[i] = 9999;
        previo[i] = -1;
    }

    // si inicia la distancia con el valor 0 devido que el origen con su mismo orgien 
    //no posee distancia por lo tanto ese valor 
    distancia[nodoorigen] = 0; 
    
    
    //recorremos la matriz y calculamos los posibles caminos 

    for (int j = 0; j< numV - 1; j++)  
    { 
  
        for (int i= 0; i < numA; i++)  
        {             
            if (distancia[matriz[i][0]] + matriz[i][2] < distancia[matriz[i][1]]) {
                distancia[matriz[i][1]] = distancia[matriz[i][0]] + matriz[i][2];
                previo[matriz[i][1]] = matriz[i][0];
            }
        } 
    } 
      
    
    // En el caso el ciclo sea negativo 
  
    for (int i = 0; i < numV; i++)  
    { 
        int peso = matriz[i][2]; 
        int origen = matriz[i][0]; 
        int destino = matriz[i][1]; 
        
        
        if (distancia[origen] != 9999 && 
                distancia[origen] + peso < distancia[destino]) 
            System.out.println("Ciclo con peso negativo"); 
    } 
    
    // realizamos los estructura para obtener el resultado 
  
    System.out.println("Vertice\t\tDistancia\tPrevio"); 
    System.out.println("---------------------------------------------");
    for (int i = 0; i < numV; i++) 
        System.out.println(i + "\t\t" + distancia[i] + "\t\t" + previo[i]);
    
    System.out.println("Camino Corto [ Nodo " + nodoorigen + " a Nodo " + nododestino + "]");
    System.out.println("---------------------------------------------");
    
    System.out.print("Recorrido ");
    int suma;
    suma = camino_corto(previo, matriz, nododestino, 0, numA);
    System.out.print("\nTotal Recorrido en Peso : " + suma);
    System.out.println("");
    
 
} 
  

public static void main(String[] args)  
{ 
    // metodo para halla el tiendo de ejecucion
    long inicio = System.nanoTime();
    
    // ingreso de numero de vertices de la topologia
    int numV = 15; 
    //ingreso del numero de aristas de la topologia 
    int numA = 27; 
  
    // la matriz con los elementos de la topologia 
    // nodo inicio
    // nodo adyacente
    // peso de manera respectiva.
   
    System.out.println("Tabla de ejecucion" + "\n");
    int matriz[][] ={{0,5, 1},{1,0, 4},{1,2, 10},{2,7,-1},
                {3,1, 2},{3,2, 3},{3,7, 7},{3,8, 2},
                {3,9, -4},{3,11, -1},{4,0,-8},{4,1,12},
                {6,12,-1},{7,6, 6},{8,7, 3},{8,12, 4},
                {9,5, 13},{9,4, 9},{9,11, 2},{9,13, 7},
                {9,10, 9},{10,13,5},{11,8,10},{11,14,3},
                {11,13, 6},{14,13, 10},{14,12,-5}};


    // realizamos un print para que se pueda vizualizar el arreglo 
    for (int i = 0; i < matriz.length; i++) {
        
        System.out.println(Arrays.toString(matriz[i]) +"\t");

        
    }
    
    //se ejecuta la funcion BellmanForde
    // donde la matriz es la aplicada anteriormente al igual 
    // que el numero de verices y aristas
    // los dos ultimos valos es para fijar el origen y el destino 
    
    BellmanFord(matriz, numV, numA,3,6); 
    
    long fin = System.nanoTime();
    
    
    double tiempo = (double)((fin - inicio)/1000);
    
    //metodo nanoTime para el calculo del tiempo en nanosegundos
    
    System.out.println("Tiempo de ejecucion : " + tiempo + " nanosegundos"); 
    
    // funcion Runtime para hallar el uso de memoria 
    
    System.out.println("Memoria Usada : " + (Runtime.getRuntime().totalMemory() - Runtime.getRuntime().freeMemory()) +" bytes ");
    
    } 


}